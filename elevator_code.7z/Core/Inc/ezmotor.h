#ifndef INC_EZMOTOR_H_
#define INC_EZMOTOR_H_

#include "main.h"

void ezmotor_on();
void ezmotor_off();

#endif /* INC_EZMOTOR_H_ */
