#ifndef INC_ARGORITHM_H_
#define INC_ARGORITHM_H_

#include "main.h"

void argorithm();

#endif /* INC_ARGORITHM_H_ */
