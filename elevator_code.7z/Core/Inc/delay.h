
#ifndef INC_DELAY_H_
#define INC_DELAY_H_


#include "main.h"
#include "tim.h"


void delay_us(uint16_t us);







#endif /* INC_DELAY_H_ */
